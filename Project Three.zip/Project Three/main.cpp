#include <iostream>
#include <string>
#include "GroceryTracker.h"

// Displays the user menu
void displayMenu() {
    std::cout << "\n==== Corner Grocer Menu ====\n";
    std::cout << "1. Search for an item frequency\n";
    std::cout << "2. Display all item frequencies\n";
    std::cout << "3. Display histogram of items\n";
    std::cout << "4. Exit program\n";
    std::cout << "Select an option (1-4): ";
}

int main() {
    // Create a GroceryTracker object, initializing from the input file and backing up to frequency.dat
    GroceryTracker tracker("CS210_Project_Three_Input_File.txt", "frequency.dat");

    int userChoice;
    std::string itemToSearch;

    while (true) {
        displayMenu();
        std::cin >> userChoice;

        // Validate input to make sure it's a number between 1 and 4
        if (std::cin.fail()) {
            std::cin.clear(); // Clear error flag
            std::cin.ignore(1000, '\n'); // Discard invalid input
            std::cout << "Invalid input. Please enter a number between 1 and 4.\n";
            continue;
        }

        switch (userChoice) {
        case 1:
            std::cout << "Enter the item name: ";
            std::cin >> itemToSearch;
            std::cout << itemToSearch << " was purchased " << tracker.getItemFrequency(itemToSearch) << " time(s).\n";
            break;
        case 2:
            tracker.printAllItemFrequencies();
            break;
        case 3:
            tracker.printItemHistogram();
            break;
        case 4:
            std::cout << "Exiting program. Goodbye!\n";
            return 0;
        default:
            std::cout << "Please enter a valid option (1-4).\n";
        }
    }
}
