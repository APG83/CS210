#include "GroceryTracker.h"
#include <fstream>
#include <iostream>
#include <iomanip>

// Constructor: initializes map from input file and creates output backup file
GroceryTracker::GroceryTracker(const std::string& inputFileName, const std::string& outputFileName) {
    loadItemsFromFile(inputFileName);         // Load item frequencies into the map
    writeFrequenciesToFile(outputFileName);   // Backup the frequencies to a file
}

// Reads items from input file and populates the frequency map
void GroceryTracker::loadItemsFromFile(const std::string& inputFileName) {
    std::ifstream inputFile(inputFileName);
    std::string itemName;

    while (inputFile >> itemName) {
        ++itemFrequencyMap[itemName];  // Increment frequency count for each item
    }

    inputFile.close();
}

// Writes the item frequency data to a backup file
void GroceryTracker::writeFrequenciesToFile(const std::string& outputFileName) {
    std::ofstream outputFile(outputFileName);

    for (const auto& entry : itemFrequencyMap) {
        outputFile << entry.first << " " << entry.second << std::endl;
    }

    outputFile.close();
}

// Returns frequency of a specific item, or 0 if not found
int GroceryTracker::getItemFrequency(const std::string& itemName) const {
    auto it = itemFrequencyMap.find(itemName);
    return (it != itemFrequencyMap.end()) ? it->second : 0;
}

// Prints all items and their corresponding frequencies
void GroceryTracker::printAllItemFrequencies() const {
    for (const auto& entry : itemFrequencyMap) {
        std::cout << std::setw(12) << std::left << entry.first << " " << entry.second << std::endl;
    }
}

// Prints a histogram of item frequencies using asterisks
void GroceryTracker::printItemHistogram() const {
    for (const auto& entry : itemFrequencyMap) {
        std::cout << std::setw(12) << std::left << entry.first << " " << std::string(entry.second, '*') << std::endl;
    }
}
