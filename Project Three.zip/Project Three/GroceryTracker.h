#ifndef GROCERY_TRACKER_H
#define GROCERY_TRACKER_H

#include <map>
#include <string>

// GroceryTracker class definition to encapsulate all item tracking logic
class GroceryTracker {
private:
    std::map<std::string, int> itemFrequencyMap;  // Stores item names and their frequencies

    // Loads item data from the input file into the map
    void loadItemsFromFile(const std::string& inputFileName);

    // Writes the item-frequency map to an output file for backup
    void writeFrequenciesToFile(const std::string& outputFileName);

public:
    // Constructor initializes the tracker by reading from input and writing to output
    GroceryTracker(const std::string& inputFileName, const std::string& outputFileName);

    // Returns how often a specific item appears in the data
    int getItemFrequency(const std::string& itemName) const;

    // Displays all items and their frequencies
    void printAllItemFrequencies() const;

    // Displays a histogram showing item frequency visually
    void printItemHistogram() const;
};

#endif
